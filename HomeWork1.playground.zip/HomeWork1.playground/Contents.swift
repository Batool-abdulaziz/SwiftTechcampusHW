
//Batool Alhumaidi
import Cocoa

// Dictionary of dishes and their prices
let menu = ["Pasta": 54.0, "Rice": 65.0, "Pizza": 34.0]

// Array to store prices of the dishes ordered by the customer
var invoice = [menu["Pasta"],menu["Rice"]]

// Function to calculate total price of the order

var totalPrice = 0.0

func total(inv : [Double]){
    if inv.isEmpty{
        return
    }
    for i in inv {
            totalPrice+=i
    }
    
}

total(inv:invoice)
print("your total is \(totalPrice)$")
